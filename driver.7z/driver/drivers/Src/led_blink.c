#include "STM32F4XX.h"
#include "stm32f4xx_gpio_driver.h"
void delay(void)
{
	for(uint32_t i=0;i<500000;i++);

}
int main()
{
GPIO_HANDLE_t GPIO_LED;
GPIO_LED.pGPIOx = GPIOD;
GPIO_LED.PIN_CONGFIG.GPIO_PinNumber = GPIO_Pin_Number_12;
GPIO_LED.PIN_CONGFIG.GPIO_PinMode = GPIO_Pin_Mode_Out;
GPIO_LED.PIN_CONGFIG.GPIO_PinSpeed = GPIO_Pin_Speed_Fast;
GPIO_LED.PIN_CONGFIG.GPIO_PinOPType = GPIO_Pin_PP;
GPIO_LED.PIN_CONGFIG.GPIO_PinPuPdControl=GPIO_Pin_PU;
GPIO_PeriClockControl(GPIOD, ENABLE);
GPIO_Init(&GPIO_LED);

while(1)
{

	GPIO_ToggleOutputPin(GPIOD, 12);
	delay();

}
}
